package com.molnia.browser.models

import android.content.Context
import androidx.room.*

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY addedAt DESC")
    suspend fun getAll(): List<Bookmark>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: Bookmark): Long
    @Delete
    suspend fun delete(bookmark: Bookmark)
    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteById(id: Long)
    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE url = :url)")
    suspend fun exists(url: String): Boolean
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY visitedAt DESC LIMIT 500")
    suspend fun getAll(): List<HistoryEntry>
    @Insert
    suspend fun insert(entry: HistoryEntry)
    @Query("DELETE FROM history")
    suspend fun clearAll()
    @Query("DELETE FROM history WHERE id = :id")
    suspend fun deleteById(id: Long)
    @Query("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY visitedAt DESC LIMIT 500)")
    suspend fun trimOld()
}

@Database(entities = [Bookmark::class, HistoryEntry::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "molnia_browser.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
