package com.molnia.browser.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.webkit.WebSettings
import android.webkit.WebView

object WebViewChecker {

    private const val MIN_CHROMIUM_VERSION = 109

    private val WEBVIEW_PACKAGES = listOf(
        "com.google.android.webview",
        "com.android.webview",
        "com.google.android.chrome",
        "com.amazon.webview.chromium",  // Amazon WebView
        "com.microsoft.emmx"
    )

    data class WebViewInfo(
        val packageName: String,
        val versionName: String,
        val chromiumVersion: Int,
        val isUpToDate: Boolean,
        val userAgent: String
    )

    fun getWebViewInfo(context: Context): WebViewInfo? {
        return try {
            val userAgent = try { WebSettings.getDefaultUserAgent(context) } catch (e: Exception) { "" }
            val chromiumVersion = extractChromiumMajor(userAgent)
            val pm = context.packageManager
            var packageName = "неизвестно"
            var versionName = "?"

            for (pkg in WEBVIEW_PACKAGES) {
                try {
                    val info = pm.getPackageInfo(pkg, 0)
                    packageName = pkg; versionName = info.versionName ?: "?"; break
                } catch (e: PackageManager.NameNotFoundException) { continue }
            }

            if (packageName == "неизвестно" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WebView.getCurrentWebViewPackage()?.let {
                    packageName = it.packageName; versionName = it.versionName ?: "?"
                }
            }

            WebViewInfo(packageName, versionName, chromiumVersion,
                chromiumVersion >= MIN_CHROMIUM_VERSION, userAgent)
        } catch (e: Exception) { null }
    }

    fun getUpdateIntent(): Intent = try {
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.webview"))
    } catch (e: Exception) {
        Intent(Intent.ACTION_VIEW,
            Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.webview"))
    }

    /** Amazon WebView — актуальный Chromium, не требует GMS, доступен на Fire TV и Android TV Box */
    fun getAmazonWebViewIntent(): Intent =
        Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.amazon.com/gp/mas/dl/android?p=com.amazon.webview.chromium"))

    fun extractChromiumMajor(userAgent: String): Int =
        Regex("Chrome/(\\d+)").find(userAgent)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    fun extractChromiumFull(userAgent: String): String =
        Regex("Chrome/([\\d.]+)").find(userAgent)?.groupValues?.get(1) ?: "?"
}
