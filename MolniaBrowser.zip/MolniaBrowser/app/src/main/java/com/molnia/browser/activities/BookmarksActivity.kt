package com.molnia.browser.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.molnia.browser.R
import com.molnia.browser.adapters.BookmarkAdapter
import com.molnia.browser.databinding.ActivityBookmarksBinding
import com.molnia.browser.models.AppDatabase
import kotlinx.coroutines.launch

class BookmarksActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBookmarksBinding
    private lateinit var adapter: BookmarkAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookmarksBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = BookmarkAdapter(
            bookmarks = emptyList(),
            onClick = { bookmark ->
                val intent = Intent(this, BrowserActivity::class.java).apply {
                    putExtra(BrowserActivity.EXTRA_URL, bookmark.url)
                    putExtra(BrowserActivity.EXTRA_INCOGNITO, false)
                }
                startActivity(intent)
            },
            onLongClick = { bookmark ->
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.bookmark_delete))
                    .setMessage(bookmark.title)
                    .setPositiveButton(getString(R.string.confirm)) { _, _ ->
                        lifecycleScope.launch {
                            AppDatabase.getInstance(this@BookmarksActivity)
                                .bookmarkDao()
                                .delete(bookmark)
                            loadBookmarks()
                        }
                    }
                    .setNegativeButton(getString(R.string.cancel), null)
                    .show()
            }
        )

        // Сетка 4 колонки для TV
        binding.rvBookmarks.layoutManager = GridLayoutManager(this, 4)
        binding.rvBookmarks.adapter = adapter

        loadBookmarks()
    }

    private fun loadBookmarks() {
        lifecycleScope.launch {
            val bookmarks = AppDatabase.getInstance(this@BookmarksActivity)
                .bookmarkDao()
                .getAll()
            adapter.update(bookmarks)
            binding.tvEmpty.visibility = if (bookmarks.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
