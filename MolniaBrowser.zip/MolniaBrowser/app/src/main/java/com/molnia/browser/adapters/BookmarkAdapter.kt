package com.molnia.browser.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.molnia.browser.R
import com.molnia.browser.models.Bookmark
import com.molnia.browser.utils.UrlUtils

class BookmarkAdapter(
    private var bookmarks: List<Bookmark>,
    private val onClick: (Bookmark) -> Unit,
    private val onLongClick: (Bookmark) -> Unit = {}
) : RecyclerView.Adapter<BookmarkAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val favicon: ImageView = view.findViewById(R.id.ivFavicon)
        val title: TextView = view.findViewById(R.id.tvBookmarkTitle)
        val url: TextView = view.findViewById(R.id.tvBookmarkUrl)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_bookmark, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val bookmark = bookmarks[position]

        holder.title.text = bookmark.title.ifEmpty {
            UrlUtils.extractDomain(bookmark.url)
        }
        holder.url.text = UrlUtils.extractDomain(bookmark.url)

        // Загружаем favicon через Glide
        Glide.with(holder.favicon.context)
            .load(UrlUtils.getFaviconUrl(bookmark.url))
            .placeholder(android.R.drawable.ic_menu_compass)
            .error(android.R.drawable.ic_menu_compass)
            .into(holder.favicon)

        holder.itemView.setOnClickListener { onClick(bookmark) }
        holder.itemView.setOnLongClickListener {
            onLongClick(bookmark)
            true
        }
        holder.itemView.isFocusable = true
        holder.itemView.isFocusableInTouchMode = true
    }

    override fun getItemCount() = bookmarks.size

    fun update(newBookmarks: List<Bookmark>) {
        bookmarks = newBookmarks
        notifyDataSetChanged()
    }
}
