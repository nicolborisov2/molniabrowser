package com.molnia.browser.activities

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.molnia.browser.adapters.BookmarkAdapter
import com.molnia.browser.databinding.ActivityMainBinding
import com.molnia.browser.models.AppDatabase
import com.molnia.browser.utils.AdBlocker
import com.molnia.browser.utils.PrefsManager
import com.molnia.browser.utils.UrlUtils
import com.molnia.browser.utils.WebViewChecker
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsManager
    private lateinit var bookmarkAdapter: BookmarkAdapter
    private var isIncognitoMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager.getInstance(this)
        setupSearchBar()
        setupButtons()
        setupFavorites()
        checkWebViewAndInit()
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
        binding.tvIncognitoIndicator.visibility =
            if (isIncognitoMode) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun checkWebViewAndInit() {
        lifecycleScope.launch {
            if (prefs.isAdBlockEnabled) {
                AdBlocker.isEnabled = true
                AdBlocker.init(this@MainActivity)
            }
            val info = WebViewChecker.getWebViewInfo(this@MainActivity)
            if (info != null && !info.isUpToDate) showWebViewWarning(info)
        }
    }

    private fun showWebViewWarning(info: WebViewChecker.WebViewInfo) {
        AlertDialog.Builder(this)
            .setTitle("⚠️ Устаревший движок браузера")
            .setMessage(
                "Обнаружена старая версия Chromium (${info.chromiumVersion}).\n\n" +
                "Рекомендуется обновить Android System WebView.\n\n" +
                "Если Play Store недоступен — можно установить Amazon WebView " +
                "(актуальный Chromium от Amazon, доступен без GMS)."
            )
            .setPositiveButton("Обновить WebView") { _, _ ->
                startActivity(WebViewChecker.getUpdateIntent())
            }
            .setNeutralButton("Amazon WebView") { _, _ ->
                startActivity(WebViewChecker.getAmazonWebViewIntent())
            }
            .setNegativeButton("Продолжить", null)
            .show()
    }

    private fun setupSearchBar() {
        binding.etSearchBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) { performSearch(); true } else false
        }
        binding.btnSearch.setOnClickListener { performSearch() }
    }

    private fun performSearch() {
        val query = binding.etSearchBar.text.toString().trim()
        if (query.isEmpty()) return
        openBrowser(UrlUtils.buildUrl(query, prefs.searchEngine))
    }

    private fun setupButtons() {
        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        binding.btnBookmarks.setOnClickListener {
            startActivity(Intent(this, BookmarksActivity::class.java))
        }
        binding.btnIncognito.setOnClickListener {
            isIncognitoMode = !isIncognitoMode
            binding.tvIncognitoIndicator.visibility =
                if (isIncognitoMode) android.view.View.VISIBLE else android.view.View.GONE
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnAbout.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }

    private fun setupFavorites() {
        bookmarkAdapter = BookmarkAdapter(
            bookmarks = emptyList(),
            onClick = { bookmark -> openBrowser(bookmark.url) },
            onLongClick = { bookmark ->
                lifecycleScope.launch {
                    AppDatabase.getInstance(this@MainActivity).bookmarkDao().delete(bookmark)
                    loadFavorites()
                }
            }
        )
        binding.rvFavorites.apply {
            layoutManager = LinearLayoutManager(
                this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = bookmarkAdapter
        }
    }

    private fun loadFavorites() {
        lifecycleScope.launch {
            val bookmarks = AppDatabase.getInstance(this@MainActivity).bookmarkDao().getAll()
            bookmarkAdapter.update(bookmarks)
        }
    }

    private fun openBrowser(url: String) {
        startActivity(Intent(this, BrowserActivity::class.java).apply {
            putExtra(BrowserActivity.EXTRA_URL, url)
            putExtra(BrowserActivity.EXTRA_INCOGNITO, isIncognitoMode)
        })
    }
}
