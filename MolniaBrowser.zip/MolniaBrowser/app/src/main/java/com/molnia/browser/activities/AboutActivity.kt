package com.molnia.browser.activities

import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.molnia.browser.BuildConfig
import com.molnia.browser.databinding.ActivityAboutBinding
import com.molnia.browser.utils.AdBlocker
import com.molnia.browser.utils.WebViewChecker

class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(com.molnia.browser.R.string.about)

        binding.tvAppVersion.text = "Версия ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"

        // Создаём временный WebView чтобы получить UA ПОСЛЕ инициализации провайдера.
        // Это единственный надёжный способ узнать реально загруженный движок.
        // Не пытаемся определить версию Chromium — это ненадёжно.
        // Просто показываем установленный пакет WebView.
        val info = WebViewChecker.getWebViewInfo(this)
        binding.tvChromiumVersion.text = if (info != null) {
            buildString {
                append("Chromium ${info.userAgent.substringAfter("Chrome/").substringBefore(" ")}")
                if (!info.isUpToDate) append("  ⚠️ устарел (< 109)")
            }
        } else "неизвестно"

        // Пакет и версия WebView APK
        binding.tvWebViewPackage.text = info?.packageName ?: "неизвестно"
        binding.tvWebViewPackageVersion.text = info?.versionName ?: "?"

        binding.tvAndroidVersion.text = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        binding.tvDeviceInfo.text = "${Build.MANUFACTURER} ${Build.MODEL}"

        binding.tvAdBlockStats.text = if (AdBlocker.isLoaded)
            "Заблокировано в этой сессии: ${AdBlocker.blockedCount} запросов"
        else "Блокировщик не активен"
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
