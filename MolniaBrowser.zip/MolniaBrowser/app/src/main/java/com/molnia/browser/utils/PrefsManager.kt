package com.molnia.browser.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        PreferenceManager.getDefaultSharedPreferences(context)

    var searchEngine: SearchEngine
        get() = SearchEngine.fromKey(prefs.getString("search_engine", "google") ?: "google")
        set(value) = prefs.edit().putString("search_engine", value.key).apply()

    var homepage: String
        get() = prefs.getString("homepage", "about:blank") ?: "about:blank"
        set(value) = prefs.edit().putString("homepage", value).apply()

    var isJavaScriptEnabled: Boolean
        get() = prefs.getBoolean("javascript_enabled", true)
        set(value) = prefs.edit().putBoolean("javascript_enabled", value).apply()

    var isCookiesEnabled: Boolean
        get() = prefs.getBoolean("cookies_enabled", true)
        set(value) = prefs.edit().putBoolean("cookies_enabled", value).apply()

    var textSizePercent: Int
        get() = (prefs.getString("text_size", "100") ?: "100").toIntOrNull() ?: 100
        set(value) = prefs.edit().putString("text_size", value.toString()).apply()

    var isAdBlockEnabled: Boolean
        get() = prefs.getBoolean("adblock_enabled", true)
        set(value) = prefs.edit().putBoolean("adblock_enabled", value).apply()

    companion object {
        @Volatile private var INSTANCE: PrefsManager? = null
        fun getInstance(context: Context): PrefsManager =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: PrefsManager(context.applicationContext).also { INSTANCE = it }
            }
    }
}
