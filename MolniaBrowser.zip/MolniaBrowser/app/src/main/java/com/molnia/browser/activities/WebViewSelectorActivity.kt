package com.molnia.browser.activities

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.molnia.browser.R
import com.molnia.browser.databinding.ActivityWebviewSelectorBinding
import com.molnia.browser.utils.WebViewProviderManager
import com.molnia.browser.utils.isRootAvailable
import com.molnia.browser.utils.tryMethod4_RootSu
import com.molnia.browser.utils.tryMethod5_WebViewUpgrade
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class WebViewSelectorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWebviewSelectorBinding
    private var providers = listOf<WebViewProviderManager.WebViewPackageInfo>()
    private lateinit var adapter: ProviderAdapter

    // Провайдер выбранный пользователем в списке (ещё не применённый)
    private var pendingProvider: WebViewProviderManager.WebViewPackageInfo? = null
    private var hasRoot = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWebviewSelectorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Движок браузера (WebView)"

        adapter = ProviderAdapter(emptyList()) { selected -> onProviderSelected(selected) }
        binding.rvProviders.layoutManager = LinearLayoutManager(this)
        binding.rvProviders.adapter = adapter

        binding.btnRescan.setOnClickListener { loadProviders() }
        binding.btnReset.setOnClickListener { resetToSystem() }

        // Кнопка root — появляется только если root доступен
        binding.btnApplyRoot.visibility = View.GONE
        binding.btnApplyRoot.setOnClickListener {
            pendingProvider?.let { applyViaRoot(it) }
                ?: Toast.makeText(this, "Сначала выберите провайдер из списка", Toast.LENGTH_SHORT).show()
        }

        loadProviders()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    private fun loadProviders() {
        binding.progressScan.visibility = View.VISIBLE
        binding.tvScanStatus.text = "Сканируем устройство…"
        binding.rvProviders.visibility = View.GONE
        binding.btnApplyRoot.visibility = View.GONE

        lifecycleScope.launch {
            // Параллельно проверяем root и сканируем провайдеры
            val rootCheck = withContext(Dispatchers.IO) { isRootAvailable() }
            providers = withContext(Dispatchers.IO) {
                WebViewProviderManager.detectAllProviders(this@WebViewSelectorActivity)
            }
            hasRoot = rootCheck

            binding.progressScan.visibility = View.GONE
            binding.rvProviders.visibility = View.VISIBLE

            val currentSelected = WebViewProviderManager.getSelectedProvider(this@WebViewSelectorActivity)
            val systemProvider = WebViewProviderManager.getCurrentSystemProvider(this@WebViewSelectorActivity)

            binding.tvScanStatus.text = buildString {
                append("Найдено провайдеров: ${providers.size}  |  ")
                append("Системный: ${systemProvider ?: "?"}\n")
                if (currentSelected != null && currentSelected != systemProvider)
                    append("Выбран вручную: $currentSelected\n")
                if (hasRoot) append("✅ Root доступен — можно применить через su")
                else append("⚠️ Root не обнаружен — доступна только рефлексия")
            }

            // Показываем кнопку root только если root есть
            if (hasRoot) {
                binding.btnApplyRoot.visibility = View.VISIBLE
            }

            adapter.update(providers, currentSelected ?: systemProvider)
            binding.tvEmpty.visibility = if (providers.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun onProviderSelected(info: WebViewProviderManager.WebViewPackageInfo) {
        val systemProvider = WebViewProviderManager.getCurrentSystemProvider(this)
        val currentSelected = WebViewProviderManager.getSelectedProvider(this)

        if (info.packageName == currentSelected ||
            (currentSelected == null && info.packageName == systemProvider)) {
            Toast.makeText(this, "Этот провайдер уже используется", Toast.LENGTH_SHORT).show()
            return
        }

        // Запоминаем выбор для кнопки root
        pendingProvider = info

        val msg = buildString {
            append("Провайдер: ${info.label}\n")
            append("Пакет: ${info.packageName}\n")
            append("Версия APK: ${info.versionName}\n")
            if (info.chromiumVersion > 0) append("Chromium: ${info.chromiumVersion}\n")
            append(if (info.isSystem) "Тип: системный\n" else "Тип: пользовательский\n")
            append("\n")
            if (hasRoot) {
                append("Root обнаружен. Выберите способ применения:\n\n")
                append("• «Через Root» — надёжный способ, изменяет системный провайдер\n")
                append("• «Через рефлексию» — без root, может не сработать на этой прошивке")
            } else {
                append("Root не обнаружен. Будет использована рефлексия.\n")
                append("На некоторых прошивках (Amlogic) это может не сработать.")
            }
        }

        val builder = AlertDialog.Builder(this).setTitle("Выбор провайдера WebView").setMessage(msg)

        if (hasRoot) {
            builder.setPositiveButton("⚡ Через Root (рекомендуется)") { _, _ ->
                applyViaRoot(info)
            }
            builder.setNeutralButton("Через рефлексию") { _, _ ->
                applyViaReflection(info)
            }
        } else {
            builder.setPositiveButton("Применить") { _, _ ->
                applyViaReflection(info)
            }
        }

        builder.setNegativeButton("Отмена", null).show()
    }

    // ─── Применение через Root ────────────────────────────────────────────────

    private fun applyViaRoot(info: WebViewProviderManager.WebViewPackageInfo) {
        binding.progressScan.visibility = View.VISIBLE
        binding.tvScanStatus.text = "Применяем через root…"

        lifecycleScope.launch {
            WebViewProviderManager.saveSelectedProvider(
                this@WebViewSelectorActivity, info.packageName)

            val result = withContext(Dispatchers.IO) {
                tryMethod4_RootSu(info.packageName)
            }

            binding.progressScan.visibility = View.GONE

            when (result) {
                is WebViewProviderManager.ApplyResult.Success -> {
                    AlertDialog.Builder(this@WebViewSelectorActivity)
                        .setTitle("✅ Применено через Root")
                        .setMessage(
                            "Провайдер «${info.label}» установлен как системный WebView.\n\n" +
                            "Метод: ${result.method}\n\n" +
                            "Браузер будет перезапущен."
                        )
                        .setPositiveButton("Перезапустить") { _, _ -> restartApp() }
                        .setCancelable(false)
                        .show()
                }
                is WebViewProviderManager.ApplyResult.Error -> {
                    AlertDialog.Builder(this@WebViewSelectorActivity)
                        .setTitle("❌ Root-команда не сработала")
                        .setMessage(
                            "${result.reason}\n\n" +
                            "Попробуйте вручную через ADB или терминал на приставке:\n\n" +
                            "su\ncmd webviewupdate set-webview-implementation ${info.packageName}"
                        )
                        .setPositiveButton("Попробовать рефлексию") { _, _ ->
                            applyViaReflection(info)
                        }
                        .setNegativeButton("Отмена") { _, _ ->
                            WebViewProviderManager.clearSelectedProvider(this@WebViewSelectorActivity)
                        }
                        .show()
                }
            }
        }
    }

    // ─── Применение через рефлексию ───────────────────────────────────────────

    private fun applyViaReflection(info: WebViewProviderManager.WebViewPackageInfo) {
        binding.progressScan.visibility = View.VISIBLE
        binding.tvScanStatus.text = "Применяем через рефлексию…"

        lifecycleScope.launch {
            WebViewProviderManager.saveSelectedProvider(
                this@WebViewSelectorActivity, info.packageName)

            // Сначала пробуем WebViewUpgrade (метод 5) — наиболее эффективен для несистемных APK
            val result = withContext(Dispatchers.IO) {
                val r5 = tryMethod5_WebViewUpgrade(this@WebViewSelectorActivity, info.packageName)
                if (r5 is WebViewProviderManager.ApplyResult.Success) r5
                else WebViewProviderManager.applyProvider(this@WebViewSelectorActivity, info.packageName)
            }

            binding.progressScan.visibility = View.GONE

            when (result) {
                is WebViewProviderManager.ApplyResult.Success -> {
                    AlertDialog.Builder(this@WebViewSelectorActivity)
                        .setTitle("✅ Провайдер применён")
                        .setMessage("«${info.label}» активирован.\nМетод: ${result.method}\n\nПерезапустить браузер?")
                        .setPositiveButton("Перезапустить") { _, _ -> restartApp() }
                        .setCancelable(false)
                        .show()
                }
                is WebViewProviderManager.ApplyResult.Error -> {
                    AlertDialog.Builder(this@WebViewSelectorActivity)
                        .setTitle("⚠️ Рефлексия не сработала")
                        .setMessage(
                            "${result.reason}\n\n" +
                            if (hasRoot) "Попробуйте кнопку «Применить через Root»."
                            else "На этой прошивке без root изменить WebView-провайдер не удастся.\n\n" +
                                "Альтернатива: через ADB на компьютере:\nadb shell cmd webviewupdate set-webview-implementation ${info.packageName}"
                        )
                        .setPositiveButton(if (hasRoot) "Через Root" else "OK") { _, _ ->
                            if (hasRoot) applyViaRoot(info)
                            else WebViewProviderManager.clearSelectedProvider(this@WebViewSelectorActivity)
                        }
                        .setNegativeButton("Отмена") { _, _ ->
                            WebViewProviderManager.clearSelectedProvider(this@WebViewSelectorActivity)
                        }
                        .show()
                }
            }
        }
    }

    private fun resetToSystem() {
        AlertDialog.Builder(this)
            .setTitle("Сбросить к системному?")
            .setMessage("Браузер забудет кастомный выбор и будет использовать системный WebView.\n\nПосле сброса браузер перезапустится.")
            .setPositiveButton("Сбросить") { _, _ ->
                // Просто забываем сохранённый выбор — системный WebView вернётся автоматически
                WebViewProviderManager.clearSelectedProvider(this)
                restartApp()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun restartApp() {
        val intent = packageManager.getLaunchIntentForPackage(packageName)!!
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    // ─── Адаптер ──────────────────────────────────────────────────────────────

    inner class ProviderAdapter(
        private var items: List<WebViewProviderManager.WebViewPackageInfo>,
        private val onClick: (WebViewProviderManager.WebViewPackageInfo) -> Unit
    ) : RecyclerView.Adapter<ProviderAdapter.ViewHolder>() {

        private var selectedPackage: String? = null

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvName: TextView = view.findViewById(R.id.tvProviderName)
            val tvPackage: TextView = view.findViewById(R.id.tvProviderPackage)
            val tvVersion: TextView = view.findViewById(R.id.tvProviderVersion)
            val tvChromium: TextView = view.findViewById(R.id.tvProviderChromium)
            val tvType: TextView = view.findViewById(R.id.tvProviderType)
            val tvActive: TextView = view.findViewById(R.id.tvProviderActive)
        }

        fun update(newItems: List<WebViewProviderManager.WebViewPackageInfo>, selected: String?) {
            items = newItems
            selectedPackage = selected
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_webview_provider, parent, false)
            return ViewHolder(view)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val info = items[position]
            val isSelected = info.packageName == selectedPackage

            holder.tvName.text = info.label
            holder.tvPackage.text = info.packageName
            holder.tvVersion.text = "APK: ${info.versionName}"
            holder.tvChromium.text = if (info.chromiumVersion > 0)
                "Chromium ${info.chromiumVersion}" else "Версия не определена"
            holder.tvType.text = if (info.isSystem) "🔒 Системный" else "📦 Пользовательский"
            holder.tvActive.text = if (isSelected) "✅ АКТИВЕН" else ""
            holder.tvActive.visibility = if (isSelected) View.VISIBLE else View.GONE

            holder.itemView.setBackgroundResource(
                if (isSelected) R.drawable.card_selected else R.drawable.card_selector)

            holder.itemView.isFocusable = true
            holder.itemView.isFocusableInTouchMode = true
            holder.itemView.setOnClickListener { onClick(info) }
        }
    }
}
