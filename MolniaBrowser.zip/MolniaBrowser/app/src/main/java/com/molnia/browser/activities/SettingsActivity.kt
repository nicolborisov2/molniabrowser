package com.molnia.browser.activities

import android.content.Intent
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreference
import com.molnia.browser.R
import com.molnia.browser.utils.AdBlocker
import com.molnia.browser.utils.WebViewProviderManager
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.settings)
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            // Движок браузера (WebView)
            findPreference<Preference>("webview_engine")?.apply {
                val selected = WebViewProviderManager.getSelectedProvider(requireContext())
                val system = WebViewProviderManager.getCurrentSystemProvider(requireContext())
                summary = if (selected != null && selected != system)
                    "Выбран вручную: $selected"
                else
                    "Системный: ${system ?: "неизвестен"}"

                setOnPreferenceClickListener {
                    startActivity(Intent(requireContext(), WebViewSelectorActivity::class.java))
                    true
                }
            }

            // Блокировщик рекламы
            findPreference<SwitchPreference>("adblock_enabled")
                ?.setOnPreferenceChangeListener { _, newValue ->
                    val enabled = newValue as Boolean
                    AdBlocker.isEnabled = enabled
                    if (enabled && !AdBlocker.isLoaded) {
                        val ctx = requireContext()
                        lifecycleScope.launch {
                            Toast.makeText(ctx, "Загружаем фильтры рекламы…", Toast.LENGTH_SHORT).show()
                            AdBlocker.init(ctx)
                            Toast.makeText(ctx, "Блокировщик готов", Toast.LENGTH_SHORT).show()
                        }
                    }
                    true
                }

            findPreference<Preference>("adblock_update")?.setOnPreferenceClickListener {
                val ctx = requireContext()
                lifecycleScope.launch {
                    Toast.makeText(ctx, "Обновляем фильтры рекламы…", Toast.LENGTH_LONG).show()
                    AdBlocker.forceUpdate(ctx)
                    Toast.makeText(ctx, "Фильтры обновлены", Toast.LENGTH_SHORT).show()
                }
                true
            }

            // Очистка
            findPreference<Preference>("clear_cache")?.setOnPreferenceClickListener {
                WebView(requireContext()).clearCache(true)
                WebStorage.getInstance().deleteAllData()
                Toast.makeText(requireContext(), R.string.cache_cleared, Toast.LENGTH_SHORT).show()
                true
            }
            findPreference<Preference>("clear_history")?.setOnPreferenceClickListener {
                val ctx = requireContext()
                lifecycleScope.launch {
                    val dao = com.molnia.browser.models.AppDatabase.getInstance(ctx).historyDao()
                    dao.clearAll()
                    Toast.makeText(ctx, R.string.history_cleared, Toast.LENGTH_SHORT).show()
                }
                true
            }
            findPreference<Preference>("clear_cookies")?.setOnPreferenceClickListener {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                Toast.makeText(requireContext(), R.string.cookies_cleared, Toast.LENGTH_SHORT).show()
                true
            }
        }
    }
}
