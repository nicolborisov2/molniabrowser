package com.molnia.browser.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.molnia.browser.R
import com.molnia.browser.databinding.ActivityBrowserBinding
import com.molnia.browser.models.AppDatabase
import com.molnia.browser.models.Bookmark
import com.molnia.browser.models.HistoryEntry
import com.molnia.browser.utils.AdBlocker
import com.molnia.browser.utils.PrefsManager
import com.molnia.browser.utils.UrlUtils
import kotlinx.coroutines.launch

class BrowserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_INCOGNITO = "extra_incognito"

        // Шаг курсора за один одиночный нажим (dp)
        private const val STEP_SINGLE = 60f
        // Базовая скорость при удержании (dp/tick)
        private const val SPEED_BASE = 10f
        private const val SPEED_MAX = 50f
        private const val SPEED_ACCEL = 1.08f
        private const val TICK_MS = 16L
        // Если следующий DOWN пришёл быстрее этого порога — считаем удержанием
        private const val HOLD_THRESHOLD_MS = 200L
        private const val HIDE_MS = 5000L
    }

    private lateinit var binding: ActivityBrowserBinding
    private lateinit var prefs: PrefsManager
    private var isIncognito = false
    private var pageTitle = ""

    // Текущий URL — volatile т.к. читается из фонового потока Chromium
    @Volatile private var currentPageUrl: String? = null

    // Курсор
    private val density get() = resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    // Направление текущего движения: -1, 0, +1
    private var dirX = 0f
    private var dirY = 0f
    private var speed = SPEED_BASE

    // Время последнего DOWN для каждой оси — определяем удержание vs одиночный нажим
    private var lastDownTime = 0L

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (dirX == 0f && dirY == 0f) return
            val norm = if (dirX != 0f && dirY != 0f) 0.707f else 1f
            val dpSpeed = speed * density
            binding.cursorView.move(dirX * dpSpeed * norm, dirY * dpSpeed * norm)
            speed = (speed * SPEED_ACCEL).coerceAtMost(SPEED_MAX)
            handler.postDelayed(this, TICK_MS)
        }
    }

    private val hideCursorRunnable = Runnable {
        binding.cursorView.alpha = 0.3f
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBrowserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager.getInstance(this)
        isIncognito = intent.getBooleanExtra(EXTRA_INCOGNITO, false)

        setupWebView()
        setupNavPanel()

        binding.incognitoBanner.visibility = if (isIncognito) View.VISIBLE else View.GONE

        // Центрируем курсор после layout
        binding.cursorView.post {
            binding.cursorView.centerOnScreen()
            scheduleCursorHide()
        }

        loadUrl(intent.getStringExtra(EXTRA_URL) ?: prefs.homepage)
    }

    // ─── Курсор ───────────────────────────────────────────────────────────────

    /**
     * Обрабатывает нажатие D-pad кнопки.
     * Логика: каждый DOWN движет курсор плавно несколькими микрошагами (вместо одного большого шага).
     * Если следующий DOWN пришёл быстро (< HOLD_THRESHOLD_MS) — включаем режим удержания.
     */
    private fun handleCursorKeyDown(dx: Float, dy: Float) {
        android.util.Log.d("MOLNIA_CURSOR", "DOWN: dx=$dx dy=$dy")

        val now = System.currentTimeMillis()
        val isHold = (now - lastDownTime) < HOLD_THRESHOLD_MS
        lastDownTime = now

        handler.removeCallbacks(hideCursorRunnable)
        binding.cursorView.alpha = 1f

        if (isHold) {
            // Режим удержания — плавное ускоряющееся движение
            android.util.Log.d("MOLNIA_CURSOR", "HOLD mode activated")
            if (dirX != dx || dirY != dy) {
                dirX = dx
                dirY = dy
                speed = SPEED_BASE
                handler.removeCallbacks(tickRunnable)
                handler.post(tickRunnable)
            }
        } else {
            // Одиночный нажим — плавное движение на несколько микрошагов
            android.util.Log.d("MOLNIA_CURSOR", "SINGLE: smooth $STEP_SINGLE dp")
            val microSteps = 6  // количество микрошагов для плавности
            val stepSize = (STEP_SINGLE * density) / microSteps
            val norm = if (dx != 0f && dy != 0f) 0.707f else 1f

            for (i in 0 until microSteps) {
                handler.postDelayed({
                    binding.cursorView.move(dx * stepSize * norm, dy * stepSize * norm)
                }, (i * TICK_MS / 2))
            }
        }
    }

    private fun handleCursorKeyUp(axis: Char) {
        android.util.Log.d("MOLNIA_CURSOR", "UP: axis=$axis")
        if (axis == 'x') dirX = 0f else dirY = 0f
        if (dirX == 0f && dirY == 0f) {
            handler.removeCallbacks(tickRunnable)
            scheduleCursorHide()
        }
    }

    private fun scheduleCursorHide() {
        handler.removeCallbacks(hideCursorRunnable)
        handler.postDelayed(hideCursorRunnable, HIDE_MS)
    }

    private fun clickAtCursor() {
        val cx = binding.cursorView.cursorX
        val cy = binding.cursorView.cursorY
        val t = android.os.SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, cx, cy, 0)
        binding.webView.dispatchTouchEvent(down)
        down.recycle()
        handler.postDelayed({
            val up = MotionEvent.obtain(t, t + 100, MotionEvent.ACTION_UP, cx, cy, 0)
            binding.webView.dispatchTouchEvent(up)
            up.recycle()
        }, 80)
    }

    // ─── WebView ──────────────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(binding.webView.settings) {
            javaScriptEnabled = prefs.isJavaScriptEnabled
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            textZoom = prefs.textSizePercent
            allowFileAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = "$userAgentString Molnia/1.0 (Android TV)"
        }

        // Инкогнито: отключаем cookie и кэш один раз, больше не трогаем
        if (isIncognito) {
            CookieManager.getInstance().setAcceptCookie(false)
            binding.webView.clearCache(true)
            binding.webView.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        } else {
            CookieManager.getInstance().setAcceptCookie(prefs.isCookiesEnabled)
            CookieManager.getInstance().setAcceptThirdPartyCookies(
                binding.webView, prefs.isCookiesEnabled)
        }

        binding.webView.webViewClient = object : WebViewClient() {

            // ВАЖНО: вызывается из фонового потока Chromium.
            // Нельзя вызывать view.url, view.title и т.д.
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                if (!prefs.isAdBlockEnabled || !AdBlocker.isEnabled || !AdBlocker.isLoaded) {
                    return null
                }
                // Не блокируем основной документ страницы
                if (request.isForMainFrame) return null

                val url = request.url.toString()
                val lower = url.lowercase()

                // Не блокируем стили и шрифты — ломают вёрстку
                if (lower.endsWith(".css") || lower.contains(".css?") ||
                    lower.endsWith(".woff") || lower.endsWith(".woff2") ||
                    lower.endsWith(".ttf") || lower.endsWith(".otf") ||
                    lower.endsWith(".eot") || lower.contains("font")) {
                    return null
                }

                return if (AdBlocker.shouldBlock(url, currentPageUrl)) {
                    WebResourceResponse("text/plain", "utf-8", "".byteInputStream())
                } else null
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                currentPageUrl = url
                binding.progressBar.visibility = View.VISIBLE
                binding.progressBar.progress = 0
                url?.let { binding.etUrl.setText(it) }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                currentPageUrl = url
                binding.progressBar.visibility = View.GONE
                url?.let { binding.etUrl.setText(it) }
                pageTitle = view.title ?: url ?: ""

                // Сохраняем историю только в обычном режиме
                if (!isIncognito && !url.isNullOrEmpty() && url != "about:blank") {
                    saveHistory(url, pageTitle)
                }
                updateAdBlockCounter()
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(
                        this@BrowserActivity,
                        getString(R.string.error_page_load),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                binding.progressBar.progress = newProgress
                if (newProgress == 100) binding.progressBar.visibility = View.GONE
            }
            override fun onReceivedTitle(view: WebView, title: String?) {
                pageTitle = title ?: ""
            }
        }
    }

    // ─── История ──────────────────────────────────────────────────────────────

    private fun saveHistory(url: String, title: String) {
        lifecycleScope.launch {
            try {
                val dao = AppDatabase.getInstance(this@BrowserActivity).historyDao()
                dao.insert(HistoryEntry(url = url, title = title.ifEmpty { url }))
                dao.trimOld()
            } catch (e: Exception) { /* некритично */ }
        }
    }

    private fun updateAdBlockCounter() {
        if (prefs.isAdBlockEnabled && AdBlocker.isEnabled) {
            binding.tvAdBlockCount.text = "🛡 ${AdBlocker.blockedCount}"
            binding.tvAdBlockCount.visibility = View.VISIBLE
        } else {
            binding.tvAdBlockCount.visibility = View.GONE
        }
    }

    // ─── Навигационная панель ─────────────────────────────────────────────────

    private fun setupNavPanel() {
        binding.etUrl.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) { navigateToUrl(); true } else false
        }
        binding.btnGo.setOnClickListener { navigateToUrl() }
        binding.btnNavBack.setOnClickListener {
            if (binding.webView.canGoBack()) binding.webView.goBack()
        }
        binding.btnNavForward.setOnClickListener {
            if (binding.webView.canGoForward()) binding.webView.goForward()
        }
        binding.btnNavHome.setOnClickListener {
            hideNavPanel()
            startActivity(Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            })
            finish()
        }
        binding.btnNavRefresh.setOnClickListener {
            binding.webView.reload()
            hideNavPanel()
        }
        binding.btnNavBookmark.setOnClickListener { addCurrentPageToBookmarks() }
    }

    // ─── D-pad ────────────────────────────────────────────────────────────────

    /**
     * dispatchKeyEvent вызывается ДО того как события доходят до WebView.
     * Обрабатываем курсор, затем ТАКЖЕ пускаем события в WebView для прокрутки страницы.
     */
    override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
        event ?: return super.dispatchKeyEvent(event)

        val keyCode = event.keyCode
        val isDown = event.action == KeyEvent.ACTION_DOWN
        val isUp = event.action == KeyEvent.ACTION_UP

        // Если панель открыта — обрабатываем только BACK
        if (binding.navPanel.visibility == View.VISIBLE) {
            return when (keyCode) {
                KeyEvent.KEYCODE_BACK -> { if (isDown) hideNavPanel(); true }
                else -> super.dispatchKeyEvent(event)
            }
        }

        // Обрабатываем курсор
        val handled = when {
            isDown && keyCode == KeyEvent.KEYCODE_BACK -> { showNavPanel(); true }
            isDown && keyCode == KeyEvent.KEYCODE_DPAD_UP -> { handleCursorKeyDown(0f, -1f); true }
            isDown && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> { handleCursorKeyDown(0f, 1f); true }
            isDown && keyCode == KeyEvent.KEYCODE_DPAD_LEFT -> { handleCursorKeyDown(-1f, 0f); true }
            isDown && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT -> { handleCursorKeyDown(1f, 0f); true }
            isUp && keyCode == KeyEvent.KEYCODE_DPAD_UP -> { handleCursorKeyUp('y'); true }
            isUp && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> { handleCursorKeyUp('y'); true }
            isUp && keyCode == KeyEvent.KEYCODE_DPAD_LEFT -> { handleCursorKeyUp('x'); true }
            isUp && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT -> { handleCursorKeyUp('x'); true }
            isDown && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) -> {
                clickAtCursor(); true
            }
            else -> false
        }

        // ВАЖНО: после обработки курсора ТАКЖЕ пускаем события в WebView для прокрутки.
        // WebView используют стрелки для прокрутки контента.
        if (handled && keyCode in listOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
        )) {
            // Пускаем событие дальше в WebView для прокрутки
            return super.dispatchKeyEvent(event)
        }

        return if (handled) true else super.dispatchKeyEvent(event)
    }

    private fun showNavPanel() {
        binding.navPanel.visibility = View.VISIBLE
        binding.btnNavBack.requestFocus()
    }

    private fun hideNavPanel() {
        binding.navPanel.visibility = View.GONE
        binding.webView.requestFocus()
    }

    private fun navigateToUrl() {
        val input = binding.etUrl.text.toString().trim()
        if (input.isEmpty()) return
        loadUrl(UrlUtils.buildUrl(input, prefs.searchEngine))
        hideNavPanel()
    }

    private fun loadUrl(url: String) { binding.webView.loadUrl(url) }

    // ─── Закладки ─────────────────────────────────────────────────────────────

    private fun addCurrentPageToBookmarks() {
        val url = currentPageUrl ?: binding.webView.url ?: return
        val title = pageTitle.ifEmpty { UrlUtils.extractDomain(url) }
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(this@BrowserActivity).bookmarkDao()
            if (dao.exists(url)) {
                Toast.makeText(this@BrowserActivity, "Уже в закладках", Toast.LENGTH_SHORT).show()
            } else {
                dao.insert(Bookmark(
                    title = title, url = url,
                    faviconUrl = UrlUtils.getFaviconUrl(url)
                ))
                Toast.makeText(
                    this@BrowserActivity,
                    getString(R.string.bookmark_added),
                    Toast.LENGTH_SHORT
                ).show()
                binding.btnNavBookmark.setImageResource(android.R.drawable.btn_star_big_on)
            }
        }
        hideNavPanel()
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        binding.webView.destroy()
        if (isIncognito) {
            binding.webView.clearCache(true)
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
        super.onDestroy()
    }
}
