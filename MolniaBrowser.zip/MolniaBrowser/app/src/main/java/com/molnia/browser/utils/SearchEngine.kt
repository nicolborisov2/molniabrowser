package com.molnia.browser.utils

enum class SearchEngine(val key: String, val displayName: String, val searchUrl: String) {
    GOOGLE("google", "Google", "https://www.google.com/search?q="),
    YANDEX("yandex", "Яндекс (ya.ru)", "https://ya.ru/search/?text="),
    DUCKDUCKGO("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q=");

    companion object {
        fun fromKey(key: String): SearchEngine =
            values().find { it.key == key } ?: GOOGLE
    }
}

object UrlUtils {
    private val URL_PATTERN = Regex(
        "^(https?://)?([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,}(/.*)?$"
    )

    /**
     * Если строка похожа на URL — возвращает нормализованный URL.
     * Иначе — строит поисковый запрос.
     */
    fun buildUrl(input: String, searchEngine: SearchEngine): String {
        val trimmed = input.trim()
        return when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.startsWith("about:") -> trimmed
            URL_PATTERN.matches(trimmed) -> "https://$trimmed"
            else -> searchEngine.searchUrl + android.net.Uri.encode(trimmed)
        }
    }

    fun extractDomain(url: String): String {
        return try {
            android.net.Uri.parse(url).host ?: url
        } catch (e: Exception) {
            url
        }
    }

    fun getFaviconUrl(url: String): String {
        val domain = extractDomain(url)
        return "https://www.google.com/s2/favicons?domain=$domain&sz=64"
    }
}
