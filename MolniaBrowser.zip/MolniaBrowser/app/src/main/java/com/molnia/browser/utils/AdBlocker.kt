package com.molnia.browser.utils

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.regex.Pattern

/**
 * Блокировщик рекламы с поддержкой фильтров в формате ABP (Adblock Plus).
 * Загружает EasyList + RuAdList и парсит правила в оперативной памяти.
 */
object AdBlocker {

    private const val TAG = "AdBlocker"

    // Источники фильтров
    private val FILTER_URLS = listOf(
        // EasyList — основной международный список
        "https://easylist.to/easylist/easylist.txt",
        // RuAdList — специально для русскоязычных сайтов
        "https://easylist-downloads.adblockplus.org/ruadlist+easylist.txt"
    )

    // Кэш-файлы для оффлайн-работы
    private const val CACHE_FILE_EASY = "easylist.txt"
    private const val CACHE_FILE_RU = "ruadlist.txt"

    // Максимальный возраст кэша — 24 часа
    private const val CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1000L

    // Разобранные правила
    private val blockedDomains = HashSet<String>(50_000)       // точные домены
    private val blockedPatterns = CopyOnWriteArrayList<Regex>() // regex-паттерны
    private val whitelistPatterns = CopyOnWriteArrayList<Regex>() // исключения (@@)

    @Volatile
    var isEnabled = true

    @Volatile
    var isLoaded = false

    var blockedCount = 0L
        private set

    /**
     * Инициализация: загружаем фильтры (из кэша или сети).
     */
    suspend fun init(context: Context) = withContext(Dispatchers.IO) {
        try {
            val cacheFiles = listOf(CACHE_FILE_EASY, CACHE_FILE_RU)
            val filterUrls = FILTER_URLS

            filterUrls.forEachIndexed { i, url ->
                val cacheFile = context.getFileStreamPath(cacheFiles[i])
                val useCache = cacheFile.exists() &&
                        (System.currentTimeMillis() - cacheFile.lastModified()) < CACHE_MAX_AGE_MS

                val text = if (useCache) {
                    Log.d(TAG, "Загружаем фильтры из кэша: ${cacheFiles[i]}")
                    cacheFile.readText()
                } else {
                    Log.d(TAG, "Загружаем фильтры из сети: $url")
                    try {
                        val downloaded = downloadFilterList(url)
                        cacheFile.writeText(downloaded)
                        downloaded
                    } catch (e: Exception) {
                        Log.w(TAG, "Не удалось загрузить $url, используем кэш если есть")
                        if (cacheFile.exists()) cacheFile.readText() else ""
                    }
                }

                if (text.isNotEmpty()) parseFilterList(text)
            }

            isLoaded = true
            Log.i(TAG, "Блокировщик готов: ${blockedDomains.size} доменов, " +
                    "${blockedPatterns.size} паттернов")
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка инициализации блокировщика", e)
        }
    }

    /**
     * Проверяет, нужно ли заблокировать URL.
     * Вызывается из WebViewClient.shouldInterceptRequest — должен быть быстрым.
     */
    fun shouldBlock(url: String, pageUrl: String? = null): Boolean {
        if (!isEnabled || !isLoaded) return false
        if (url.startsWith("data:") || url.startsWith("about:")) return false

        // Сначала проверяем whitelist
        if (isWhitelisted(url, pageUrl)) return false

        // Быстрая проверка по домену
        val domain = extractDomain(url)
        if (domain != null && blockedDomains.contains(domain)) {
            blockedCount++
            return true
        }

        // Медленная проверка по паттернам
        for (pattern in blockedPatterns) {
            if (pattern.containsMatchIn(url)) {
                blockedCount++
                return true
            }
        }

        return false
    }

    private fun isWhitelisted(url: String, pageUrl: String?): Boolean {
        for (pattern in whitelistPatterns) {
            if (pattern.containsMatchIn(url)) return true
        }
        return false
    }

    // ─── Парсинг фильтров ABP ─────────────────────────────────────────────────

    private fun parseFilterList(text: String) {
        var domainCount = 0
        var patternCount = 0

        text.lineSequence().forEach { rawLine ->
            val line = rawLine.trim()
            when {
                // Пропускаем комментарии и заголовки
                line.isEmpty() || line.startsWith("!") || line.startsWith("[") -> return@forEach

                // Whitelist правила (исключения) @@...
                line.startsWith("@@") -> {
                    val pattern = abpRuleToRegex(line.removePrefix("@@")) ?: return@forEach
                    whitelistPatterns.add(pattern)
                }

                // Правила блокировки доменов ||domain^
                line.startsWith("||") && line.endsWith("^") -> {
                    val domain = line.removePrefix("||").removeSuffix("^")
                        .substringBefore("^").substringBefore("/")
                    if (isValidDomain(domain)) {
                        blockedDomains.add(domain)
                        domainCount++
                    }
                }

                // Правила с опциями ||domain^ $option,...
                line.startsWith("||") && line.contains("^") -> {
                    val domainPart = line.removePrefix("||")
                        .substringBefore("^").substringBefore("/")
                    if (isValidDomain(domainPart)) {
                        blockedDomains.add(domainPart)
                        domainCount++
                    }
                }

                // CSS-правила (элементное скрытие) — пропускаем, WebView их не поддерживает нативно
                line.contains("##") || line.contains("#@#") || line.contains("#?#") -> return@forEach

                // Обычные паттерны — конвертируем в regex
                else -> {
                    if (patternCount < 5000) { // ограничиваем кол-во regex для производительности
                        val pattern = abpRuleToRegex(line) ?: return@forEach
                        blockedPatterns.add(pattern)
                        patternCount++
                    }
                }
            }
        }
    }

    /**
     * Конвертирует ABP-правило в Regex.
     * ABP wildcards: * = любая строка, ^ = разделитель
     */
    private fun abpRuleToRegex(rule: String): Regex? {
        return try {
            // Убираем опции ($image, $script и т.д.)
            val cleanRule = if (rule.contains("\$")) rule.substringBefore("\$") else rule
            if (cleanRule.length < 4) return null

            val regexStr = buildString {
                append("(?i)") // case-insensitive
                cleanRule.forEach { c ->
                    when (c) {
                        '*' -> append(".*")
                        '^' -> append("[/?&=;]?")
                        '.' -> append("\\.")
                        '?' -> append("\\?")
                        '[' -> append("\\[")
                        ']' -> append("\\]")
                        '(' -> append("\\(")
                        ')' -> append("\\)")
                        '|' -> { /* якоря обрабатываем отдельно */ }
                        else -> append(c)
                    }
                }
            }
            Regex(regexStr)
        } catch (e: Exception) {
            null
        }
    }

    private fun extractDomain(url: String): String? {
        return try {
            val uri = android.net.Uri.parse(url)
            uri.host?.removePrefix("www.")
        } catch (e: Exception) {
            null
        }
    }

    private fun isValidDomain(s: String): Boolean {
        if (s.isEmpty() || s.length > 253) return false
        return s.matches(Regex("[a-zA-Z0-9._\\-]+\\.[a-zA-Z]{2,}"))
    }

    private fun downloadFilterList(urlStr: String): String {
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.setRequestProperty("User-Agent", "Molnia Browser/1.0")
        conn.connect()

        if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode}")

        return BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
            .use { it.readText() }
    }

    /**
     * Принудительно обновить фильтры (удалить кэш и перезагрузить).
     */
    suspend fun forceUpdate(context: Context) = withContext(Dispatchers.IO) {
        listOf(CACHE_FILE_EASY, CACHE_FILE_RU).forEach { name ->
            context.getFileStreamPath(name).delete()
        }
        blockedDomains.clear()
        blockedPatterns.clear()
        whitelistPatterns.clear()
        isLoaded = false
        blockedCount = 0
        init(context)
    }
}
