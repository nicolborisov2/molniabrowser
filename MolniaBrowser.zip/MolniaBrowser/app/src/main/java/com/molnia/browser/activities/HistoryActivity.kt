package com.molnia.browser.activities

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.molnia.browser.R
import com.molnia.browser.databinding.ActivityHistoryBinding
import com.molnia.browser.models.AppDatabase
import com.molnia.browser.models.HistoryEntry
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "История"

        adapter = HistoryAdapter(
            items = emptyList(),
            onClick = { entry ->
                startActivity(Intent(this, BrowserActivity::class.java).apply {
                    putExtra(BrowserActivity.EXTRA_URL, entry.url)
                    putExtra(BrowserActivity.EXTRA_INCOGNITO, false)
                })
            },
            onLongClick = { entry ->
                AlertDialog.Builder(this)
                    .setTitle("Удалить из истории?")
                    .setMessage(entry.title)
                    .setPositiveButton("Удалить") { _, _ ->
                        lifecycleScope.launch {
                            AppDatabase.getInstance(this@HistoryActivity)
                                .historyDao().deleteById(entry.id)
                            loadHistory()
                        }
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            }
        )

        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = adapter

        binding.btnClearHistory.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Очистить всю историю?")
                .setPositiveButton("Очистить") { _, _ ->
                    lifecycleScope.launch {
                        AppDatabase.getInstance(this@HistoryActivity).historyDao().clearAll()
                        loadHistory()
                        Toast.makeText(this@HistoryActivity,
                            getString(R.string.history_cleared), Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Отмена", null)
                .show()
        }

        loadHistory()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    private fun loadHistory() {
        lifecycleScope.launch {
            val items = AppDatabase.getInstance(this@HistoryActivity).historyDao().getAll()
            adapter.update(items)
            binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    inner class HistoryAdapter(
        private var items: List<HistoryEntry>,
        private val onClick: (HistoryEntry) -> Unit,
        private val onLongClick: (HistoryEntry) -> Unit
    ) : RecyclerView.Adapter<HistoryAdapter.VH>() {

        private val dateFmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvTitle: TextView = view.findViewById(R.id.tvHistoryTitle)
            val tvUrl: TextView = view.findViewById(R.id.tvHistoryUrl)
            val tvDate: TextView = view.findViewById(R.id.tvHistoryDate)
        }

        fun update(newItems: List<HistoryEntry>) { items = newItems; notifyDataSetChanged() }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
            LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val entry = items[position]
            holder.tvTitle.text = entry.title.ifEmpty { entry.url }
            holder.tvUrl.text = entry.url
            holder.tvDate.text = dateFmt.format(Date(entry.visitedAt))
            holder.itemView.setOnClickListener { onClick(entry) }
            holder.itemView.setOnLongClickListener { onLongClick(entry); true }
            holder.itemView.isFocusable = true
            holder.itemView.isFocusableInTouchMode = true
        }
    }
}
