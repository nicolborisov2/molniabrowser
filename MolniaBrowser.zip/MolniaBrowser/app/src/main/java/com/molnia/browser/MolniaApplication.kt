package com.molnia.browser

import android.app.Application
import android.util.Log
import com.molnia.browser.utils.WebViewProviderManager

class MolniaApplication : Application() {

    companion object {
        private const val TAG = "MolniaApp"
    }

    override fun onCreate() {
        super.onCreate()
        // Весь блок в try/catch(Throwable) — краш здесь убивает приложение до старта
        try {
            applyWebViewProviderIfNeeded()
        } catch (t: Throwable) {
            Log.e(TAG, "Ошибка применения WebView провайдера — сбрасываем выбор", t)
            // Сбрасываем сохранённый выбор чтобы при следующем запуске не крашиться снова
            try { WebViewProviderManager.clearSelectedProvider(this) } catch (ignored: Throwable) { }
        }
    }

    private fun applyWebViewProviderIfNeeded() {
        val selectedPackage = WebViewProviderManager.getSelectedProvider(this) ?: return
        val currentSystem = WebViewProviderManager.getCurrentSystemProvider(this)

        if (selectedPackage == currentSystem) {
            Log.i(TAG, "Выбранный провайдер совпадает с системным — пропускаем")
            return
        }

        Log.i(TAG, "Применяем сохранённый WebView провайдер: $selectedPackage")
        when (val result = WebViewProviderManager.applyProvider(this, selectedPackage)) {
            is WebViewProviderManager.ApplyResult.Success ->
                Log.i(TAG, "Провайдер применён: ${result.packageName} (${result.method})")
            is WebViewProviderManager.ApplyResult.Error ->
                Log.w(TAG, "Не удалось применить провайдер: ${result.reason}")
        }
    }
}
