package com.molnia.browser.utils

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import android.webkit.WebView
import dalvik.system.PathClassLoader
import java.io.File

object WebViewProviderManager {

    private const val TAG = "WebViewProvider"
    private const val PREF_SELECTED_PROVIDER = "selected_webview_provider"

    private val KNOWN_WEBVIEW_PACKAGES = listOf(
        "com.google.android.webview",
        "com.google.android.chrome",
        "com.android.webview",
        "com.amazon.webview.chromium",
        "com.microsoft.emmx",
        "org.ungoogled.chromium.webview"
    )

    data class WebViewPackageInfo(
        val packageName: String,
        val versionName: String,
        val versionCode: Long,
        val chromiumVersion: Int,
        val isSystem: Boolean,
        val isCurrentProvider: Boolean,
        val apkPath: String,
        val label: String
    ) {
        val isUsable: Boolean get() = apkPath.isNotEmpty() && File(apkPath).exists()
    }

    fun detectAllProviders(context: Context): List<WebViewPackageInfo> {
        val pm = context.packageManager
        val result = mutableListOf<WebViewPackageInfo>()
        val currentProviderPackage = getCurrentSystemProvider(context)

        for (pkgName in KNOWN_WEBVIEW_PACKAGES) {
            try {
                val info = getPackageInfoCompat(pm, pkgName)
                buildWebViewPackageInfo(pm, info, currentProviderPackage)?.let { result.add(it) }
            } catch (e: PackageManager.NameNotFoundException) { }
        }

        try {
            pm.getInstalledPackages(PackageManager.GET_META_DATA).forEach { pkgInfo ->
                if (KNOWN_WEBVIEW_PACKAGES.contains(pkgInfo.packageName)) return@forEach
                if (isWebViewProvider(pm, pkgInfo)) {
                    buildWebViewPackageInfo(pm, pkgInfo, currentProviderPackage)?.let { result.add(it) }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Ошибка сканирования пакетов", e)
        }

        return result.sortedWith(
            compareByDescending<WebViewPackageInfo> { it.isCurrentProvider }
                .thenByDescending { it.chromiumVersion }
        )
    }

    private fun buildWebViewPackageInfo(
        pm: PackageManager,
        pkgInfo: PackageInfo,
        currentProviderPackage: String?
    ): WebViewPackageInfo? {
        return try {
            val appInfo = pkgInfo.applicationInfo ?: return null
            val apkPath = appInfo.sourceDir ?: return null
            if (!File(apkPath).exists()) return null
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                pkgInfo.longVersionCode
            else @Suppress("DEPRECATION") pkgInfo.versionCode.toLong()
            val label = try { pm.getApplicationLabel(appInfo).toString() }
                catch (e: Exception) { pkgInfo.packageName }
            WebViewPackageInfo(
                packageName = pkgInfo.packageName,
                versionName = pkgInfo.versionName ?: "?",
                versionCode = versionCode,
                chromiumVersion = extractChromiumVersionFromPackage(pkgInfo),
                isSystem = isSystem,
                isCurrentProvider = pkgInfo.packageName == currentProviderPackage,
                apkPath = apkPath,
                label = label
            )
        } catch (e: Exception) {
            Log.w(TAG, "Ошибка обработки ${pkgInfo.packageName}", e)
            null
        }
    }

    private fun isWebViewProvider(pm: PackageManager, pkgInfo: PackageInfo): Boolean {
        val appInfo = pkgInfo.applicationInfo ?: return false
        if (pkgInfo.packageName.contains("webview", ignoreCase = true)) return true
        appInfo.metaData?.let { meta ->
            if (meta.containsKey("com.android.webview.WebViewLibrary")) return true
        }
        try {
            val libFile = File(appInfo.nativeLibraryDir ?: return false, "libwebviewchromium.so")
            if (libFile.exists()) return true
        } catch (e: Exception) { }
        return false
    }

    private fun extractChromiumVersionFromPackage(pkgInfo: PackageInfo): Int {
        pkgInfo.applicationInfo?.metaData
            ?.getString("com.android.webview.WebViewLibrary")
            ?.let { Regex("(\\d+)").find(it)?.groupValues?.get(1)?.toIntOrNull() }
            ?.let { return it }
        pkgInfo.versionName?.substringBefore(".")?.toIntOrNull()
            ?.let { if (it > 50) return it }
        return 0
    }

    fun getCurrentSystemProvider(context: Context): String? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try { return WebView.getCurrentWebViewPackage()?.packageName } catch (e: Exception) { }
        }
        return null
    }

    fun applyProvider(context: Context, packageName: String): ApplyResult {
        Log.i(TAG, "Применяем WebView провайдер: $packageName")
        val pm = context.packageManager
        val pkgInfo = try {
            getPackageInfoCompat(pm, packageName)
        } catch (e: PackageManager.NameNotFoundException) {
            return ApplyResult.Error("Пакет $packageName не найден")
        }
        val apkPath = pkgInfo.applicationInfo?.sourceDir
            ?: return ApplyResult.Error("Не удалось получить путь к APK")
        if (!File(apkPath).exists()) return ApplyResult.Error("APK не существует: $apkPath")

        return tryMethod5_WebViewUpgrade(context, packageName).let { if (it is ApplyResult.Success) return it else null }
            ?: tryMethod1_WebViewFactory(pkgInfo, apkPath)
            ?: tryMethod2_PathClassLoader(context, apkPath)
            ?: tryMethod3_SystemService(packageName)
            ?: ApplyResult.Error("Рефлексия не сработала. Попробуйте применить через Root.")
    }

    private fun tryMethod1_WebViewFactory(pkgInfo: PackageInfo, apkPath: String): ApplyResult? {
        return try {
            val factory = Class.forName("android.webkit.WebViewFactory")
            val fieldNames = listOf("sPackageInfo", "sProviderPackageInfo", "mCurrentWebViewPackage")
            var fieldSet = false
            for (name in fieldNames) {
                try {
                    val f = factory.getDeclaredField(name)
                    f.isAccessible = true
                    f.set(null, pkgInfo)
                    fieldSet = true
                    Log.d(TAG, "Поле $name установлено")
                    break
                } catch (t: Throwable) {
                    Log.d(TAG, "Поле $name недоступно: ${t.message}")
                }
            }
            if (!fieldSet) return null
            val loader = PathClassLoader(apkPath, null, ClassLoader.getSystemClassLoader())
            for (name in listOf("sWebViewClassLoader", "mWebViewClassLoader", "sClassLoader")) {
                try {
                    val f = factory.getDeclaredField(name)
                    f.isAccessible = true
                    f.set(null, loader)
                    break
                } catch (t: Throwable) { }
            }
            Log.i(TAG, "Метод 1 (WebViewFactory) применён")
            ApplyResult.Success(pkgInfo.packageName, "WebViewFactory reflection")
        } catch (t: Throwable) {
            Log.w(TAG, "Метод 1 не сработал: ${t.message}")
            null
        }
    }

    private fun tryMethod2_PathClassLoader(context: Context, apkPath: String): ApplyResult? {
        return try {
            val appLoader = context.classLoader
            val webViewLoader = PathClassLoader(apkPath, null, appLoader)
            val parentField = ClassLoader::class.java.getDeclaredField("parent")
            parentField.isAccessible = true
            val originalParent = parentField.get(appLoader)
            parentField.set(webViewLoader, originalParent)
            parentField.set(appLoader, webViewLoader)
            Log.i(TAG, "Метод 2 (PathClassLoader) применён")
            ApplyResult.Success("", "PathClassLoader")
        } catch (t: Throwable) {
            Log.w(TAG, "Метод 2 не сработал: ${t.message}")
            null
        }
    }

    private fun tryMethod3_SystemService(packageName: String): ApplyResult? {
        return try {
            val smClass = Class.forName("android.os.ServiceManager")
            val getBinder = smClass.getDeclaredMethod("getService", String::class.java)
            getBinder.isAccessible = true
            val binder = getBinder.invoke(null, "webviewupdate") ?: return null
            val stubClass = Class.forName("android.webkit.IWebViewUpdateService\$Stub")
            val asInterface = stubClass.getDeclaredMethod("asInterface", Class.forName("android.os.IBinder"))
            asInterface.isAccessible = true
            val service = asInterface.invoke(null, binder)
            val changeMethod = service.javaClass.getDeclaredMethod("changeProviderAndSetting", String::class.java)
            changeMethod.isAccessible = true
            changeMethod.invoke(service, packageName)
            Log.i(TAG, "Метод 3 (WebViewUpdateService) применён")
            ApplyResult.Success(packageName, "WebViewUpdateService")
        } catch (t: Throwable) {
            Log.w(TAG, "Метод 3 не сработал: ${t.message}")
            null
        }
    }

    fun saveSelectedProvider(context: Context, packageName: String) {
        context.getSharedPreferences("webview_prefs", Context.MODE_PRIVATE)
            .edit().putString(PREF_SELECTED_PROVIDER, packageName).apply()
    }

    fun getSelectedProvider(context: Context): String? =
        context.getSharedPreferences("webview_prefs", Context.MODE_PRIVATE)
            .getString(PREF_SELECTED_PROVIDER, null)

    fun clearSelectedProvider(context: Context) {
        context.getSharedPreferences("webview_prefs", Context.MODE_PRIVATE)
            .edit().remove(PREF_SELECTED_PROVIDER).apply()
    }

    private fun getPackageInfoCompat(pm: PackageManager, packageName: String): PackageInfo =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(PackageManager.GET_META_DATA.toLong()))
        else @Suppress("DEPRECATION")
            pm.getPackageInfo(packageName, PackageManager.GET_META_DATA)

    sealed class ApplyResult {
        data class Success(val packageName: String, val method: String) : ApplyResult()
        data class Error(val reason: String) : ApplyResult()
    }
}

// ─── Root ─────────────────────────────────────────────────────────────────────

fun isRootAvailable(): Boolean {
    val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su",
        "/system/su", "/su/bin/su", "/magisk/.core/bin/su"
    )
    for (p in suPaths) {
        if (File(p).exists()) return true
    }
    return false
}

/**
 * Применяет WebView-провайдер через su.
 * Пробует несколько вариантов синтаксиса su, т.к. прошивки отличаются.
 * Ошибка "invalid uid/gid '-c'" означает что прошивка не поддерживает su -c.
 * В таком случае используется su 0 <cmd> или stdin.
 */
fun tryMethod4_RootSu(packageName: String): WebViewProviderManager.ApplyResult {
    val log = StringBuilder()

    // Вариант А: su 0 <cmd> — Magisk, SuperSU новые версии
    val resultA = runSuCommand(log, "su 0",
        arrayOf("su", "0", "cmd", "webviewupdate", "set-webview-implementation", packageName),
        arrayOf("su", "0", "settings", "put", "global", "webview_provider", packageName),
        arrayOf("su", "0", "am", "force-stop", packageName)
    )
    if (resultA) return WebViewProviderManager.ApplyResult.Success(packageName, "su 0 (root)")

    // Вариант Б: su root <cmd>
    val resultB = runSuCommand(log, "su root",
        arrayOf("su", "root", "cmd", "webviewupdate", "set-webview-implementation", packageName),
        arrayOf("su", "root", "settings", "put", "global", "webview_provider", packageName)
    )
    if (resultB) return WebViewProviderManager.ApplyResult.Success(packageName, "su root (root)")

    // Вариант В: stdin — записываем команды в поток ввода su
    val resultC = runSuStdin(log, packageName)
    if (resultC) return WebViewProviderManager.ApplyResult.Success(packageName, "su stdin (root)")

    return WebViewProviderManager.ApplyResult.Error(
        buildString {
            append("Root-команда не дала результата.\n\n")
            append("Вывод:\n")
            append(log.toString())
        }
    )
}

private fun runSuCommand(log: StringBuilder, variant: String, vararg commands: Array<String>): Boolean {
    var firstSuccess = false
    for ((index, cmd) in commands.withIndex()) {
        try {
            log.append("[$variant] ${cmd.joinToString(" ")}\n")
            val process = Runtime.getRuntime().exec(cmd)
            val stdout = process.inputStream.bufferedReader().readText()
            val stderr = process.errorStream.bufferedReader().readText()
            val exit = process.waitFor()
            if (stdout.isNotEmpty()) log.append("  out: $stdout\n")
            if (stderr.isNotEmpty()) log.append("  err: $stderr\n")
            log.append("  exit: $exit\n")
            if (index == 0 && exit == 0 && !stderr.contains("invalid") && !stderr.contains("error", ignoreCase = true)) {
                firstSuccess = true
            }
        } catch (t: Throwable) {
            log.append("  exception: ${t.message}\n")
        }
    }
    return firstSuccess
}

private fun runSuStdin(log: StringBuilder, packageName: String): Boolean {
    return try {
        log.append("[su stdin] запуск su без аргументов\n")
        val process = Runtime.getRuntime().exec("su")
        val writer = process.outputStream.bufferedWriter()
        writer.write("cmd webviewupdate set-webview-implementation $packageName")
        writer.newLine()
        writer.write("settings put global webview_provider $packageName")
        writer.newLine()
        writer.write("exit")
        writer.newLine()
        writer.flush()
        writer.close()
        val stdout = process.inputStream.bufferedReader().readText()
        val stderr = process.errorStream.bufferedReader().readText()
        val exit = process.waitFor()
        if (stdout.isNotEmpty()) log.append("  out: $stdout\n")
        if (stderr.isNotEmpty()) log.append("  err: $stderr\n")
        log.append("  exit: $exit\n")
        exit == 0 && !stderr.contains("invalid") && !stderr.contains("error", ignoreCase = true)
    } catch (t: Throwable) {
        log.append("  exception: ${t.message}\n")
        false
    }
}

/**
 * Метод 5: по мотивам WebViewUpgrade (github.com/JonaNorman/WebViewUpgrade).
 *
 * Ключевое отличие от метода 1: после подмены PackageInfo вызывает
 * WebViewFactory.prepareWebView() который инициализирует нативную библиотеку.
 * Также подменяет путь к ресурсам чтобы несистемный APK нашёл свои ресурсы.
 *
 * Это решает проблему на прошивках где простая замена поля не работает
 * из-за того что WebView не может загрузить ресурсы из несистемного пути.
 */
fun tryMethod5_WebViewUpgrade(
    context: Context,
    packageName: String
): WebViewProviderManager.ApplyResult {
    return try {
        val pm = context.packageManager
        val pkgInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(packageName,
                PackageManager.PackageInfoFlags.of(PackageManager.GET_META_DATA.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(packageName, PackageManager.GET_META_DATA)
        }

        val apkPath = pkgInfo.applicationInfo?.sourceDir
            ?: return WebViewProviderManager.ApplyResult.Error("APK path not found")

        val factory = Class.forName("android.webkit.WebViewFactory")

        // Шаг 1: подменяем PackageInfo (как в методе 1)
        val fieldNames = listOf("sPackageInfo", "sProviderPackageInfo", "mCurrentWebViewPackage")
        for (name in fieldNames) {
            try {
                val f = factory.getDeclaredField(name)
                f.isAccessible = true
                f.set(null, pkgInfo)
                break
            } catch (t: Throwable) { }
        }

        // Шаг 2: создаём Context для WebView APK чтобы он нашёл свои ресурсы
        val webViewContext = try {
            context.createPackageContext(
                packageName,
                Context.CONTEXT_INCLUDE_CODE or Context.CONTEXT_IGNORE_SECURITY
            )
        } catch (t: Throwable) { null }

        // Шаг 3: устанавливаем ClassLoader из webViewContext (он знает путь к APK)
        val loader = webViewContext?.classLoader
            ?: dalvik.system.PathClassLoader(apkPath, null, ClassLoader.getSystemClassLoader())

        for (name in listOf("sWebViewClassLoader", "mWebViewClassLoader", "sClassLoader")) {
            try {
                val f = factory.getDeclaredField(name)
                f.isAccessible = true
                f.set(null, loader)
                break
            } catch (t: Throwable) { }
        }

        // Шаг 4: вызываем prepareWebView() — инициализирует нативную libwebviewchromium.so
        // Это ключевой шаг которого нет в методе 1
        try {
            val prepare = factory.getDeclaredMethod("prepareWebView")
            prepare.isAccessible = true
            prepare.invoke(null)
            android.util.Log.i("WebViewUpgrade", "prepareWebView() вызван успешно")
        } catch (t: Throwable) {
            android.util.Log.w("WebViewUpgrade", "prepareWebView() недоступен: ${t.message}")
        }

        WebViewProviderManager.ApplyResult.Success(packageName, "WebViewUpgrade (prepareWebView)")
    } catch (t: Throwable) {
        android.util.Log.w("WebViewUpgrade", "Метод 5 не сработал: ${t.message}")
        WebViewProviderManager.ApplyResult.Error("WebViewUpgrade: ${t.message}")
    }
}
