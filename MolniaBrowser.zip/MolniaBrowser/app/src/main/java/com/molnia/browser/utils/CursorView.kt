package com.molnia.browser.utils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/**
 * Простой курсор-кружок поверх WebView.
 *
 * Намеренно простая реализация — никакой анимации, никаких Path,
 * только drawCircle в onDraw. Это гарантирует что курсор будет виден.
 *
 * Все методы потокобезопасны: move() и centerOnScreen() можно вызывать
 * из любого потока — они используют postInvalidate() а не invalidate().
 */
class CursorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var cursorX = 0f
        private set
    var cursorY = 0f
        private set

    private val density = context.resources.displayMetrics.density

    // Внешний кружок (белый полупрозрачный)
    private val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 255, 255, 255)
        style = Paint.Style.FILL
    }

    // Внутренняя точка (белая, непрозрачная)
    private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    // Обводка для видимости на светлом фоне
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 0, 0, 0)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }

    private val outerRadius = 14f * density
    private val innerRadius = 4f * density

    private var initialized = false

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!initialized && w > 0 && h > 0) {
            cursorX = w / 2f
            cursorY = h / 2f
            initialized = true
        }
    }

    override fun onDraw(canvas: Canvas) {
        // Внешний кружок
        canvas.drawCircle(cursorX, cursorY, outerRadius, outerPaint)
        // Обводка
        canvas.drawCircle(cursorX, cursorY, outerRadius, strokePaint)
        // Центральная точка
        canvas.drawCircle(cursorX, cursorY, innerRadius, innerPaint)
    }

    /**
     * Перемещает курсор на (dx, dy). Безопасен из любого потока.
     * Возвращает текущие координаты для симуляции тапа.
     */
    fun move(dx: Float, dy: Float): Pair<Float, Float> {
        val maxX = if (width > 0) width.toFloat() else 1920f
        val maxY = if (height > 0) height.toFloat() else 1080f
        cursorX = (cursorX + dx).coerceIn(outerRadius, maxX - outerRadius)
        cursorY = (cursorY + dy).coerceIn(outerRadius, maxY - outerRadius)
        postInvalidate()
        return Pair(cursorX, cursorY)
    }

    fun centerOnScreen() {
        val w = if (width > 0) width.toFloat() else 960f
        val h = if (height > 0) height.toFloat() else 540f
        cursorX = w / 2f
        cursorY = h / 2f
        initialized = true
        postInvalidate()
    }
}
